package com.dbs.seed.training.controller;

import com.dbs.seed.training.exception.ResourceNotFoundException;
import com.dbs.seed.training.model.Department;
import com.dbs.seed.training.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/")
public class DepartmentController {

    @Autowired
    DepartmentRepository departmentRepository;


    @GetMapping("/departments")
    public List<Department> getAllDepartments(){
        return departmentRepository.findAll();
    }

    // create departments rest api
    @PostMapping("/department")
    public Department createDepartment(@RequestBody Department employee) {
        return departmentRepository.save(employee);
    }

    // get departments by id rest api
    @GetMapping("/department/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) {
        Department employee = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not exist with id :" + id));
        return ResponseEntity.ok(employee);
    }

    // update departments rest api

    @PutMapping("/departments/{id}")
    public ResponseEntity<Department> updateDepartment(@PathVariable Long id, @RequestBody Department departmentDetails){
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not exist with id :" + id));

        department.setDepartmentName(departmentDetails.getDepartmentName());
        department.setAddress(departmentDetails.getAddress());
        department.setCountry(departmentDetails.getCountry());

        Department updatedDepartment = departmentRepository.save(department);
        return ResponseEntity.ok(updatedDepartment);
    }

    // delete departments rest api
    @DeleteMapping("/departments/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteDepartment(@PathVariable Long id){
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not exist with id :" + id));

        departmentRepository.delete(department);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

}
